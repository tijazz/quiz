<?php
ob_start();
session_start();
require_once 'config/core/configNew.php';
$user_obj = new configNew();
$data = $user_obj->logout();