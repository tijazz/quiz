<?php
require_once 'config/core/configNew.php';
$config= new configNew();
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>COCNSORTIUM SCHOLARSHIPS</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="Login and Registration Form with HTML5 and CSS3" />
        <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
        <meta name="author" content="Codrops" />
        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
    </head>
    <body>
        <div class="container">
            <header>
		<!--YOU CAN USE SPAN TO AKE SHIT LIGHT BLUE-->
                <center><h1> <span>Retrieve Your Account Password</span></h1></center>
            </header>
            <section>				
                <div id="container_demo" >
                    <!-- hidden anchor to stop jump http://www.css3create.com/Astuce-Empecher-le-scroll-avec-l-utilisation-de-target#wrap4  -->
                    <a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                            <?php
//start session
session_start();
//load and initialize user class
if(isset($_POST['submit'])){
    //check whether user details are empty
    if(!empty($_POST['email'])){
        //password and confirm password comparison
      $config->forgetPassword($_POST);
}
        }
    ?>



                            <form  method="post" action="forget_password.php" autocomplete="on"> 
                                <h1>GET READY</h1> 
                               
                                <p> 
                                    <label for="password" class="youpasswd" data-icon="p"><b>Your Email</b></label>
                                    <input id="email" name="email" required="required" type="email" placeholder="eg. XXXXXX" /> 
                                </p>
                              
                                <p class="login button" > 
                                    <input align="center" type="submit" value="Reset" name="submit" /> 
								</p>
                               
                            </form>
                        </div>

                        <div id="register" class="animate form">
                           <p class="change_link">  
                                    To be a member ?
                                    <a href="apply.php" class="to_register"> Click to Register </a>
                                </p>
                        </div>


                    </div>
                </div>  
            </section>
                       

        </div>
        <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/forgetpassword.js"></script>
    </body>
</html>