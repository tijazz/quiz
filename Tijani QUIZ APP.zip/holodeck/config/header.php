<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="scholarships for students in and around nigeria" />
    <meta name="author" content="Holodeck PRE-TEST Quiz Portal" />
    <meta name="keywords" content=""/>
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>CONSORTIUM SCHOLARSHIPS</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />    
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body >
    
    <div class="navbar navbar-inverse navbar-fixed-top" >
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">CONSORTIUM</a>
            </div>
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php">HOME</a></li>
		    <li><a href="apply.php">APPLY</a></li>
                     <li><a href="services.php">OFFERS</a></li>
                     <li class="dropdown1">
                     <a href="javascript:void(0)" class="dropbtn" onclick="myFunction()">THE TEST</a>
    		     <div class="dropdown-content" id="myDropdown">
      			<a href="pricing.html">TAKE THE TEST</a>
      			<a href="pretest.php">PRE-TEST</a>
      			<a href="reg-guidelines-and-faq.html">GUIDELINES AND FAQ</a>
    		</div>
  </li>
                      <li><a href="contact.php">CONTACT</a></li>
                       <li><a href="login.php">LOG IN</a></li>
           
                </ul>
            </div>
           
        </div>
    </div>
   <!--/.NAVBAR END-->
        