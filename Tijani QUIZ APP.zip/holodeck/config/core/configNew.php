<?php

class configNew {
	private $db_user = 'root';
	private $db_pass = '';
	private $db_dbname = 'holodeck';
	private $db_host = 'localhost';
	private $userTbl = 'user';
	private $stmt;
	public $dbc;

	//construct
	function __construct(){
		//session_start();
		$this->dbc = new mysqli($this->db_host, $this->db_user, $this->db_pass, $this->db_dbname);
	 	if($this->dbc->connect_error) die ($this->dbc->connect_error);
	 	//$this->addAdmins();
	}




public function getUsername($id){
		$this->stmt = $this->dbc->query("SELECT username FROM user WHERE id ='$id' ");
		if($this->stmt->num_rows > 0){
			$row = $this->stmt->fetch_assoc();
				$result = $row['username'];
			
			return $result;
		}
	}


public function addCategory($productcategory){
	
		$this->stmt = $this->dbc->query("INSERT INTO prod_category (id, prod_cat) VALUES (null, '$productcategory')" );
	}

	public function checkEmailExists($email){
		$this->stmt = $this->dbc->query("SELECT * FROM user WHERE email = '$email' ");
		return $this->stmt->num_rows;
	}
	public function getNoRow($email){
		$this->stmt = $this->dbc->query("SELECT * FROM user WHERE email = '$email' ");
		return $this->stmt->num_rows;
	}

 /*
     * Insert data into the database
     * @param string name of the table
     * @param array the data for inserting into the table
     */
    public function insert($data){
        if(!empty($data) && is_array($data)){
            $columns = '';
            $values  = '';
            $i = 0;
            if(!array_key_exists('created',$data)){
                $data['created'] = date("Y-m-d H:i:s");
            }
            if(!array_key_exists('modified',$data)){
                $data['modified'] = date("Y-m-d H:i:s");
            }
            foreach($data as $key=>$val){
                $pre = ($i > 0)?', ':'';
                $columns .= $pre.$key;
                $values  .= $pre."'".$val."'";
                $i++;
            }
            $query = "INSERT INTO ".$this->userTbl." (".$columns.") VALUES (".$values.")";
            $insert = $this->dbc->query($query);
            return $insert?$this->dbc->insert_id:false;
        }else{
            return false;
        }
    }


 /*
     * Returns rows from the database based on the conditions
     * @param string name of the table
     * @param array select, where, order_by, limit and return_type conditions
     */
    public function getRows($conditions = array()){
        $sql = 'SELECT ';
        $sql .= array_key_exists("select",$conditions)?$conditions['select']:'*';
        $sql .= ' FROM '.$this->userTbl;
        if(array_key_exists("where",$conditions)){
            $sql .= ' WHERE ';
            $i = 0;
            foreach($conditions['where'] as $key => $value){
                $pre = ($i > 0)?' AND ':'';
                $sql .= $pre.$key." = '".$value."'";
                $i++;
            }
        }
        
        if(array_key_exists("order_by",$conditions)){
            $sql .= ' ORDER BY '.$conditions['order_by']; 
        }
        
        if(array_key_exists("start",$conditions) && array_key_exists("limit",$conditions)){
            $sql .= ' LIMIT '.$conditions['start'].','.$conditions['limit']; 
        }elseif(!array_key_exists("start",$conditions) && array_key_exists("limit",$conditions)){
            $sql .= ' LIMIT '.$conditions['limit']; 
        }
        
        $result = $this->dbc->query($sql);
        
        if(array_key_exists("return_type",$conditions) && $conditions['return_type'] != 'all'){
            switch($conditions['return_type']){
                case 'count':
                    $data = $result->num_rows;
                    break;
                case 'single':
                    $data = $result->fetch_assoc();
                    break;
                default:
                    $data = '';
            }
        }else{
            if($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $data[] = $row;
                }
            }
        }
        return !empty($data)?$data:false;
    }


//pretest login function
	public function pretestLogin($pretestcode){
		$this->stmt = $this->dbc->query("SELECT id, username, email FROM user WHERE pretestcode= '$pretestcode'");
		if($this->stmt->num_rows > 0){
			$fetch = $this->stmt->fetch_array();
			//if($fetch['password'] === $password){
				session_start();
				$_SESSION['id'] = $fetch['id'];
				$_SESSION['username'] = $fetch['username'];
				header("Location:startquiz.php");
			//}
			//else{
			 //echo"<center><b style= 'color: red; bg-color: green; padding: 3px;'>Incorrect password </b></center>";
			//}
		}
		else{
			echo"<center><b style= 'color: red; bg-color: green; padding: 3px;'>Incorrect pretest code </b></center>";
		}
	} 


	
	public function getCategory()
	{
		$query = "SELECT * FROM `categories`";
		$results = mysqli_query($this->dbc, $query)  or die(mysqli_error());
		$categories = array();
		while ( $result = mysqli_fetch_assoc($results) ) {
			$categories[$result['id']] = $result['category_name'];
		}
		mysqli_close($this->dbc);
		return $categories;
	}
	
	public function getQuestions($id, $questionsInPage, $category)
	{
		$this->stmt = $this->dbc->query("INSERT INTO scores (user_id, right_answer, category_id) VALUES ('$id', 0, '$category')" );
		$_SESSION['score_id'] = mysqli_insert_id($this->dbc);
	

		$results = array();
		$this->one = $this->dbc->query("SELECT * FROM questions WHERE category_id=$category ORDER BY RAND() ");
		$rowcount = $this->one->num_rows;
		$remainder = $rowcount/$questionsInPage;
		$results['number_question'] = $questionsInPage;
		$results['remainder'] = $remainder;
		$results['rowcount'] = $rowcount;
			while ($row = $this->one->fetch_assoc()) {
				$results['questions'][] = $row;
			}
			return $results;

	}
	
	public function getAnswers(array $data)
	{
		if( !empty( $data ) ){
			$right_answer=0;
			$wrong_answer=0;
			$unanswered=0;
			$keys=array_keys($data);
			$order=join(",",$keys);
			$query = "select id,answer from questions where id IN($order) ORDER BY FIELD(id,$order)";
			$response=mysqli_query( $this->_con, $query)   or die(mysqli_error());
			
			$user_id = $_SESSION['id'];
			$score_id = $_SESSION['score_id'];
			while($result=mysqli_fetch_array($response)){
				if($result['answer']==$_POST[$result['id']]){
					$right_answer++;
				}else if($data[$result['id']]=='smart_quiz'){
					$unanswered++;
				}
				else{
					$wrong_answer++;
				}
			}
			$results = array();
			$results['right_answer'] = $right_answer;
			$results['wrong_answer'] = $wrong_answer;
			$results['unanswered'] = $unanswered;
			$update_query = "update scores set right_answer='$right_answer', wrong_answer = '$wrong_answer', unanswered = '$unanswered' where user_id='$user_id' and id ='$score_id' ";
			mysqli_query( $this->_con, $update_query)   or die(mysqli_error());
			mysqli_close($this->_con);
			return $results;
		}	
	}





	public function getURL($val){
		if (isset($_GET[$val])){
			$val = $_GET[$val];
			return $val;
		}
	}

	public function changeAdminPassword($session, $password){
		$this->stmt = $this->dbc->query("UPDATE admin SET password = '$password' WHERE id = '$session'");
		if($this->stmt){
			 echo"<center><b style= 'color: green; bg-color: green; padding: 3px;'>Password Successful changed.
			 <br/>Your new password is ".$password."</b></center>";
		}
		else{
			echo "Error ".$this->dbc->error;
		
		}
		
	}
public function loginn($username, $password)
	{
		$_SESSION['logged_in'] = false;
		// Trim all the incoming data:
		//	$trimmed_data = array_map('trim', $data);
			
			// escape variables for security
			//$email = mysqli_real_escape_string( $this->dbc,  $username);
			//$password = mysqli_real_escape_string( $this->dbc,  $password );
				
			$password = md5( $password );
		$query = "SELECT id, name, email, created FROM user where email = '$username' or username= '$username' and password = '$password' ";
			$result = mysqli_query($this->dbc, $query);
			$data = mysqli_fetch_assoc($result);
			$count = mysqli_num_rows($result);
			mysqli_close($this->dbc);
			if( $count == 1){
				//$_SESSION = $data;
				$_SESSION['logged_in'] = true;
				header('Location : portal.php');
				return true;
			}else{
				throw new Exception(LOGIN_FAIL);
			}
		
	}
	

	function login($username, $password){
		$password = md5( $password );
		$result = $this->dbc->query("SELECT * FROM user WHERE username='$username' or  email = '$username' AND password='$password'");
				//checking if the details is available in the table
	        	$user_data = $result->fetch_array();
	        	$count_row = $result->num_rows;

		        if ($count_row == 1) {
		        		$_SESSION['id'] = $user_data['id'];
			           	$_SESSION['username'] = $user_data['username']; 
			          $_SESSION['logged_in'] = true;
				
			           	 header("Location: home.php");

		        	/*
		        	//for Admin Login portal
		        	$value = $this->fieldMarker($user_id);
		        	if($value == true){
		        		@session_start();
			            $_SESSION['id'] = $user_data['user_id'];
			            $exploded = explode('/', $username);
			            $menuid = strtoupper($exploded[1]);
			            $_SESSION['menuid'] = $menuid;
			            if($menuid == "ADMIN"){
			            	$ref = "../admin/".$ref;
			            	header("Location: $ref");
			            }
			            else{
			            	header("Location: index.php");
			            }
		        	}
		        	else{
		        		die("Can't login. Please contact developer");
		        	}
		            */
					
		       }
		  		else{
				    //return false;
				    echo"<center><b style= 'color: red; padding: 3px;'>Incorrect username/email or
				    	password .</b></center>";
				}
        	}
    	




        public function fieldMarker($id){
        	$sql = "SELECT * FROM user WHERE field_marker = 'o' AND user_id = $id";
        	$query = $this->dbc->query($sql);
        	if($query->num_rows > 0){
        		return true;
        	}
        	else{
        		return false;
        	}

        }



	public function account( array $data )
	{
		if( !empty( $data ) ){
			// Trim all the incoming data:
			$trimmed_data = array_map('trim', $data);
			
			// escape variables for security
			$password = mysqli_real_escape_string( $this->dbc, $trimmed_data['password'] );
			$cpassword = $trimmed_data['confirm_password'];
			$user_id = $_SESSION['id'];
			if((!$password) || (!$cpassword) ) {
				throw new Exception( FIELDS_MISSING );
			}
			if ($password !== $cpassword) {
				throw new Exception( PASSWORD_NOT_MATCH );
			}
			$password = md5( $password );
			$query = "UPDATE users SET password = '$password' WHERE id = '$user_id'";
			if(mysqli_query($this->dbc, $query)){
				mysqli_close($this->dbc);
				return true;
			}
		} else{
			throw new Exception( FIELDS_MISSING );
		}
	}
	
	/**
	 * This handle sign out process
	 */
	public function logout()
	{
		session_unset();
		session_destroy();
		session_start();
		$_SESSION['success'] = LOGOUT_SUCCESS;
		header('Location: login.php');
	}
	
	/**
	 * This reset the current password and send new password to mail
	 * @param array $data
	 * @throws Exception
	 * @return boolean
	 */
	public function forgetPassword( array $data )
	{
		if( !empty( $data ) ){
			
			// escape variables for security
			$email = mysqli_real_escape_string( $this->dbc, trim( $data['email'] ) );
			
			if((!$email) ) {
				throw new Exception( FIELDS_MISSING );
			}
			$password = $this->randomPassword();
			$password1 = md5( $password );
			$query = "UPDATE user SET password = '$password1' WHERE email = '$email'";
			if(mysqli_query($this->dbc, $query)){
				mysqli_close($this->dbc);
				$to = $email;
				$subject = "New Password Request";
				$txt = "Your New Password ".$password;
				$headers = "From: admin@holodeck.com" . "\r\n" .
						"CC: admin@holodeck.com";
					
				mail($to,$subject,$txt,$headers);
				//return true;
			}
		} else{
			throw new Exception( FIELDS_MISSING );
		}
	}
	
	/**
	 * This will generate random password
	 * @return string
	 */
	
	private function randomPassword()
	{
		$alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
		$pass = array(); //remember to declare $pass as an array
		$alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
		for ($i = 0; $i < 8; $i++) {
			$n = rand(0, $alphaLength);
			$pass[] = $alphabet[$n];
		}
		return implode($pass); //turn the array into a string
	}
	
	public function pr($data = '' )
	{
		echo "<pre>"; print_r($data); echo "</pre>";
	}
	
	

}

?>