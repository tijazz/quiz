<?php
require_once 'config/core/configNew.php';
$config= new configNew();
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>COCNSORTIUM SCHOLARSHIPS</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="Login and Registration Form with HTML5 and CSS3" />
        <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
        <meta name="author" content="Codrops" />
        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
    </head>
    <body>
        <div class="container">
            <header>
		<!--YOU CAN USE SPAN TO AKE SHIT LIGHT BLUE-->
                <center><h1> <span>WELCOME TO THE PRETEST PORTAL</span></h1></center>
            </header>
            <section>				
                <div id="container_demo" >
                    <!-- hidden anchor to stop jump http://www.css3create.com/Astuce-Empecher-le-scroll-avec-l-utilisation-de-target#wrap4  -->
                    <a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                            <?php
//start session
session_start();
//load and initialize user class
if(isset($_POST['submit'])){
    //check whether user details are empty
    if(!empty($_POST['pretest'])){
        //password and confirm password comparison
      $config->pretestLogin($_POST['pretest']);
}
        }
    ?>

                        <span>For Testing, Use 280567 or 311336</span>

                            <form  method="post" action="pretest.php" autocomplete="on"> 
                                <h1>GET READY</h1> 
                               
                                <p> 
                                    <label for="password" class="youpasswd" data-icon="p"> Your Pretest Code </label>
                                    <input id="password" name="pretest" required="required" type="password" placeholder="eg. XXXXXX" /> 
                                </p>
                              
                                <p class="login button"> 
                                    <input type="submit" value="Login" name="submit" /> 
								</p>
                               
                            </form>
                        </div>

                        <div id="register" class="animate form">
                           <p class="change_link">  
                                    To be a member ?
                                    <a href="apply.php" class="to_register"> Click to Register </a>
                                </p>
                        </div>


                    </div>
                </div>  
            </section>
                       

        </div>
    </body>
</html>