<?php
//session_start();
require_once 'config/core/configNew.php';

require_once 'config/header.php';
$config= new configNew();
?>
 <html lang="en" class="no-js"> <!--<![endif]-->
        <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
  

        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css"/>
        <link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		
   
    <body>
        <div class="container">
            <section>				
                <div id="contain_demo" >
                    <!-- hidden anchor to stop jump http://www.css3create.com/Astuce-Empecher-le-scroll-avec-l-utilisation-de-target#wrap4  -->
           <?php
//start session
session_start();
//load and initialize user class
if(isset($_POST['signupSubmit'])){
    //check whether user details are empty
    if(!empty($_POST['usernamesignup']) && !empty($_POST['emailsignup']) && !empty($_POST['passwordsignup']) && !empty($_POST['passwordsignup_confirm']) && !empty($_POST['bdate']) && !empty($_POST['schoolname']) && !empty($_POST['startdate']) && !empty($_POST['graduationdate'])  && !empty($_POST['phone']) && !empty($_POST['schoolcgpa'])){

        //password and confirm password comparison
        if($_POST['passwordsignup'] !== $_POST['passwordsignup_confirm']){
            echo "<span><center>Confirm password must match with the password.</center></span>";
}else{
    //check whether user exists in the database
    $emailCount =$config->checkEmailExists($_POST['emailsignup']);
    if ($emailCount > 0) {
            echo '<center>Email already exists, please use another email.</center>';
            }else{
                //insert user data in the database
         for ($i=0; $i <1 ; $i++) { 
             # code...
              $access= mt_rand(111111,999999);
                $prevCon['where'] = array('pretestcode' => $access);
                $prevcode= $config->getRows($prevCon);
                if ($prevcode<1){
                $userData = array(
                    'username' => $_POST['usernamesignup'],
                    'email' => $_POST['emailsignup'],
                    'password' => md5($_POST['passwordsignup']),
                     'birthdate' => $_POST['bdate'],
                    'phone' => $_POST['phone'],
                    'school' => $_POST['schoolname'],
                    'startdate' => $_POST['startdate'],
                    'graddate' => $_POST['graduationdate'],
                     'schgrdpoint' => $_POST['schoolcgpa'],
                     'pretestcode' => $access
                );
                $insert = $config->insert($userData); 
                 $to = $_POST['emailsignup'];
                $subject = "Application Successful";
                $message = 'Dear '.$_POST['usernamesignup'].', <br>
                You have registered successfully, your Pre-Test Portal ACCESS CODE is  ' .$access.". Kindly note that the submission of multiple applications <Br> for a single applicant is not allowed as such will lead to automatic disqualification.";
                $header = "From:tijaniazeez92@gmail.com"."\r\n";
              mail ($to,$subject,$message,$header);
              //MAILSERVER NEEDED TO PREVENT THE WARNING
                 if ($insert)  
                        {
      echo "Message sent successfully...<BR> You have registered successfully, Your Pre-Test Portal ACCESS CODE is  " .$access ."<h3><br> 
            Kindly note that the submission of multiple applications for a single <br> applicant is not allowed as such will lead to automatic disqualification.</b></center>";
                }else{
                    echo "<center>Error, some problem occurred!</center>";
                }
            }else{
                $i-=1;
            }
        }
    }
}
        }else{
            echo '<center>All fields are mandatory, please fill all the fields.</center>'; 
        }
    }
    ?>
                    <div id="wrapper">
      



                        <div id="register" class="anmate form">
                            <form action="apply.php" method="post" autocomplete="on"> 
                                <h1> Sign up </h1>
				<h1>Basic details</h1> 
                                <p> 
                                    <label for="usernamesignup" class="uname" >Username</label>
                                    <input id="usernamesignup" name="usernamesignup" required="required" type="text" placeholder="username" />
                                </p>
                                <p> 
                                    <label for="emailsignup" class="youmail">Email</label>
                                    <input id="emailsignup" name="emailsignup" required="required" type="email" placeholder="mymail@mail.com"/> 
                                </p>
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" >Your password </label>
                                    <input id="passwordsignup" name="passwordsignup" required="required" type="password" placeholder="eg. X8df!90EO"/>
                                </p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd">Please confirm your password </label>
                                    <input id="passwordsignup_confirm" name="passwordsignup_confirm" required="required" type="password" placeholder="eg. X8df!90EO"/>
                                </p>
                                <p> 
                                    <label for="dateofbirth" class="dob">Phone Number</label>
                                    <input id="" name="phone" required="" type="phone" placeholder="08123456789"/>
                                </p>
                                <p> 
                                    <label for="dateofbirth" class="dob" data-icon="">Date of Birth</label>
                                    <input id="" name="bdate" required="" type="date" placeholder="dd/mm/yy"/>
                                </p>
                                <p class="signin button"> 

				<h1>Education</h1>
                                <p> 
                                    <label for="schoolname" class="schname" data-icon="">School </label>
                                    <input id="schoolname" name="schoolname" required="required" type="text" placeholder="MySchoolName"/>
                                </p>

                                <p> 
                                    <label for="startdate" class="schstart" data-icon="">Start date</label>
                                    <input id="startdate" name="startdate" required="required" type="date" placeholder="dd/mm/yy"/>
                                </p>
                                <p> 
                                    <label for="graduationtdate" class="schend" data-icon="">Graduation date</label>
                                    <input id="graduationdate" name="graduationdate" required="required" type="date" placeholder="dd/mm/yy"/>
                                </p>
                                <p>
                                    <label for="schoolcgpa" class="schcgpa" data-icon="">School's grade point system</label> <br/>
                                    
                                    <select name="schoolcgpa" required="required" id="graduationdate" >
                                    <option>--Select Grade Point--</option>
                                    <option>5 points </option>
                                    <option>7 points </option>
                                     </SELECT>
                                </p>


                               <p class="signin button"> 
									<input type="submit" name="signupSubmit" value="Sign up"/> 
								</p>
                                <span class="change_link">  
								<h4>	Already a member? <a href="login.php" > log in </a></h4>
								</span>
                            </form>
                        </div>
						
                    </div>
                </div>  
            </section>
        </div>
          <script src="assets/plugins/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/plugins/bootstrap.js"></script>
  <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    </body>
</html>