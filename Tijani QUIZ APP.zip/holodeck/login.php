<?php
require_once 'config/core/configNew.php';
require_once 'config/header.php';
$config= new configNew();
?>

  <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/main.css" rel="stylesheet">

        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
      <body>
        <div class="container">
            <header>
		<!--YOU CAN USE SPAN TO AKE SHIT LIGHT BLUE-->
                <span></span>
            </header>
            <section>				
                <div id="container_demo" >
                    <!-- hidden anchor to stop jump http://www.css3create.com/Astuce-Empecher-le-scroll-avec-l-utilisation-de-target#wrap4  -->
                    <a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                            <?php
//start session
session_start();
//load and initialize user class
if(isset($_POST['submit'])){
    //check whether user details are empty
    if(!empty($_POST['username']) && !empty($_POST['password'])){
        //password and confirm password comparison
     
        $login=$config->login($_POST['username'], $_POST['password']);
       // if ($login) {
            # code...
       // }
}
        }
    ?>

                            <form  method="post" action="login.php" autocomplete="on"> 
                                <h1>Log in</h1> 
                                <p> 
                                    <label for="username" class="uname" > Email/Username </label>
                                    <input id="username" name="username" required="required" type="text" placeholder="myusername or mymail@mail.com"/>
                                </p>
                                <p> 
                                    <label for="password" class="youpasswd"> Password </label>
                                    <input id="password" name="password" required="required" type="password" placeholder="eg. X8df!90EO" /> 
                                </p>

									
                                    <H4><a href="forget_password.php">Forget Password</a></H4>
								</p>
                                <p class="login button"> 
                                    <input type="submit" value="Login" name="submit" /> 
								</p>
                                <p class="change_link">
									 
									<a href="apply.php" class="to_register">apply now</a>
								</p>
                            </form>
                        </div>

                        <div id="register" class="animate form">
                           <p class="change_link">  
                                    Already a member ?
                                    <a href="apply.php" class="to_register"> Go and log in </a>
                                </p>
                        </div>
						
                    </div>
                </div>  
            </section>
        </div>
        <script src="assets/plugins/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/plugins/bootstrap.js"></script>
  <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    </body>
</html>