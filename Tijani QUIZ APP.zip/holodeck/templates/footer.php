<div class="clearfix"></div>
	<!-- Footer -->
    <footer>
    	<div class="container-fluid">
    	 <section id="footer-sec" >
             
            <div class="container">
           <div class="row  pad-bottom" >
            <div class="col-md-4">
                <h4> <strong>ABOUT COMPANY</strong> </h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            </p>
                <a href="#" >read more</a>
                </div>
               <div class="col-md-4">
                    <h4> <strong>SOCIAL LINKS</strong> </h4>
                   <p>
                     <a href="#"><i class="fa fa-facebook-square fa-3x"  ></i></a>  
                        <a href="#"><i class="fa fa-twitter-square fa-3x"  ></i></a>  
                        <a href="#"><i class="fa fa-linkedin-square fa-3x"  ></i></a>  
                       <a href="#"><i class="fa fa-google-plus-square fa-3x"  ></i></a>  
                   </p>
                </div>
               <div class="col-md-4">
                   <h4> <strong>OUR LOCATION</strong> </h4>
                            <p>
                               234/JK , The Wondre Land, <br />
                               Newyork Street Junction  <br />
                               JUST USA -10909094
                            </p>
                    <a href="#" class="btn btn-primary" >SEND QUERY</a>
                </div>
               </div>
            </div>
    </section>         
    </div>
    </footer>
    <!-- /Footer -->
       <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="../assets/plugins/bootstrap.js"></script>
  <!-- CUSTOM SCRIPTS  -->
    <script src="../assets/js/custom.js"></script>
  </body>
</html>
<?php ob_end_flush(); ?>
<?php unset($_SESSION['success'] ); unset($_SESSION['error']);  ?>    