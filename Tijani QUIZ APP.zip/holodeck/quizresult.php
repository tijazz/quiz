<?php
session_start();
 require_once 'config/header.php';
require_once 'config/core/configNew.php';
$config= new configNew();




if(isset($_POST['submit'])){
    //check whether user details are empty
  //  if(!empty($_POST['num_questions']) && !empty($_POST['category']) ){
        //password and confirm password comparison
    //    $questionsInPage = $_POST['num_questions'];
     //   $category = $_POST['category'];
      //  $id = $_SESSION['id'];
       // $name = $_SESSION['username'];
      //      $username= $config->getUsername($id);
        //    $_SESSION['username'] = $username;
         // echo $id;
         //echo $username;
        //exit();
         //   $questions = $config->getQuestions($id, $questionsInPage, $category);
//   echo($_POST); exit();      
$result = $config->getAnswers($_POST);
				

		}
 //}


 ?>


 <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
   
<div class="content">
     	<div class="content">
     	<div class="container">
			<div class="row">
     	 		<div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
					<h1 class="text-center text_underline">Your Quiz Results:</h1>
					<br />
					<form class="form-horizontal">
						<div class="form-group mg-b50">
							<p class="col-sm-7 control-label">Right Answers:</p>
							<div class="col-sm-5">
								<span class="well ans"> <?php echo isset($result['right_answer'])? $result['right_answer']:''; ?>
								</span>
							</div>
						</div>
						<div class="form-group mg-b50">
							<p class="col-sm-7 control-label">Wrong Answers:</p>
							<div class="col-sm-5">
								<span class="well ans"> <?php echo isset($result['wrong_answer'])? $result['wrong_answer']:''; ?>
								</span>
							</div>
						</div>
						<div class="form-group mg-b50">
							<p class="col-sm-7 control-label">Unanswered Questions:</p>
							<div class="col-sm-5">
								<span class="well ans"> <?php echo isset($result['unanswered'])? $result['unanswered']:''; ?>
								</span> 
							</div>
						</div>
					</form>
					<div class="row btn-c well">
	     				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
	     					<a href="startquiz.php" class="btn btn-success btn-home">Start New Quiz</a>
	     				</div>
	     				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
	     					<a href="quizresult.php" class="btn btn-info btn-home">Your Quiz Results</a>
	     				</div>
	     			</div>
				</div>
	     		




     		<div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
					<h1 class="text-center">For Your Quiz Results, Corrections, Unanswered and Score.</h1>
					<br/>
					<p><h2 style="color: blue;"> To Activate Your Account for full Access, Click on MAKE PAYMENT button below...
				     
 <form method="POST" action="https://voguepay.com/pay/">
 <input type="hidden" name="v_merchant_id" value="5565-0048219" />
 <input type="hidden" name="memo" value="Order from Tijani Abdulazeez" />
 <input type="hidden" name="cur" value="NGN" />
 <input type="hidden" name="item_1" value="Application Fee" />
 <input type="hidden" name="price_1" value="1000" />
 <input type="hidden" name="description_1" value="Registration fee" />
 <br />
 <input type="image" src="https://voguepay.com/images/buttons/make_payment_green.png" alt="PAY" />
 </form>
   </h2> </p>
    </div>

     		</div>
     	</div>
    </div> <!-- /container -->

</div>
 <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
