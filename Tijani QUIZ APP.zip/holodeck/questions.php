<?php
session_start();
 require_once 'config/header.php';
require_once 'config/core/configNew.php';
$config= new configNew();




if(isset($_POST['submit'])){
    //check whether user details are empty
    if(!empty($_POST['num_questions']) && !empty($_POST['category']) ){
        //password and confirm password comparison
        $questionsInPage = $_POST['num_questions'];
        $category = $_POST['category'];
        $id = $_SESSION['id'];
       // echo $id; 
       // echo $questionsInPage.$category;
       // $name = $_SESSION['username'];
      //      $username= $config->getUsername($id);
        //    $_SESSION['username'] = $username;
         // echo $id;
         //echo $username;
        //exit();
         //   $questions = $config->getQuestions($id, $questionsInPage, $category);
         
$results = $config->getQuestions($id, $questionsInPage, $category);
				

		}
 }


 ?>


 <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
   
<div class="content">
     	<div class="container">
			<?php //require_once 'templates/ads.php';?>
     		<div class="row">
				<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
					<h1 class="text-center text_underline"> Timer : <span id='timer'></span> </h1>
	     			<form class="form-horizontal" role="form" id='quiz_form' method="post" action="quizresult.php">
						<?php
						
							
					$remainder = $results['remainder'];
						$number_question =  $results['number_question'];
						$rowcount =  $results['rowcount'];
						$i = 0;
						$j = 1; $k = 1;
						?>
						<?php foreach ($results['questions'] as $result) {
							 if ( $i == 0) echo "<div class='cont' id='question_splitter_$j'>";?>
							<div id='question<?php echo $k;?>' >
							<p class='questions' id="qname<?php echo $j;?>"> <?php echo $k?>.<?php echo $result['question_name'];?></p>
							<input type="radio" value="1" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer1'];?>
							<br/>
							<input type="radio" value="2" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer2'];?>
							<br/>
							
							<?php if(isset( $result['answer3'] ) && !empty( $result['answer3'] )){ ?>
							<input type="radio" value="3" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer3'];?>
							<br/>
							<?php } ?>
							
							<?php if(isset( $result['answer4'] ) && !empty( $result['answer4'] )){ ?>
							<input type="radio" value="4" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer4'];?>
							<br/>
							<?php } ?>
							
							<?php if(isset( $result['answer5'] ) && !empty( $result['answer5'] )){ ?>
							<input type="radio" value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer5'];?>
							<br/>
							<?php } ?>
							
							<?php if(isset( $result['answer6'] ) && !empty( $result['answer6'] )){ ?>
							<input type="radio" value="6" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer6'];?>
							<br/>
							<?php } ?>
							
							
							<input type="radio" checked='checked' style='display:none' value="smart_quiz" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>                                                                      
							<br/>
							</div>
							<?php
								 $i++; 
								 if ( ( $remainder < 1 ) || ( $i == $number_question && $remainder == 1 ) ) {
								 	echo "<button id='".$j."' class='next btn btn-success' type='submit'>Finish</button>";
								 	echo "</div>";
								 }  elseif ( $rowcount > $number_question  ) {
								 	if ( $j == 1 && $i == $number_question ) {
										echo "<button id='".$j."' class='next btn btn-success' type='button'>Next</button>";
										echo "</div>";
										$i = 0;
										$j++;           
									} elseif ( $k == $rowcount ) { 
										echo " <button id='".$j."' class='previous btn btn-success' type='button'>Previous</button>
													<button id='".$j."' class='next btn btn-success' type='submit'>Finish</button>";
										echo "</div>";
										$i = 0;
										$j++;
									} elseif ( $j > 1 && $i == $number_question ) {
										echo "<button id='".$j."' class='previous btn btn-success' type='button'>Previous</button>
								                    <button id='".$j."' class='next btn btn-success' type='button' >Next</button>";
										echo "</div>";
										$i = 0;
										$j++;
									}
									
								 }
								  $k++;
						     } ?>	
						</form>
	     		</div>
	     		<?php //require_once 'templates/sidebar.php';?>
			</div>
		</div>	
</div>
 <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>

<script>
		$('.cont').addClass('hide');
		$('#question_splitter_1').removeClass('hide');
		$(document).on('click','.next',function(){
		    last=parseInt($(this).attr('id'));  console.log( last );   
		    nex=last+1;
		    $('#question_splitter_'+last).addClass('hide');
		    
		    $('#question_splitter_'+nex).removeClass('hide');
		});
		
		$(document).on('click','.previous',function(){
		    last=parseInt($(this).attr('id'));     
		    pre=last-1;
		    $('#question_splitter_'+last).addClass('hide');
		    
		    $('#question_splitter_'+pre).removeClass('hide');
		});


		
        var c = 120;
        var t;
        timedCount();

        function timedCount() {

        	var hours = parseInt( c / 3600 ) % 24;
        	var minutes = parseInt( c / 60 ) % 60;
        	var seconds = c % 60;

        	var result = (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds  < 10 ? "0" + seconds : seconds);

            
        	$('#timer').html(result);
            if(c == 0 ){
            	setConfirmUnload(false);
                $("#quiz_form").submit();
            }
            c = c - 1;
            t = setTimeout(function(){ timedCount() }, 1000);
        }
	</script>

<?php  require_once 'config/footer.php';?>


<script type="text/javascript">

    // Prevent accidental navigation away
    setConfirmUnload(true);
    function setConfirmUnload(on)
    {
        window.onbeforeunload = on ? unloadMessage : null;
    }
    function unloadMessage()
    {
        return 'Your Answered Questions are resetted zero, Please select stay on page to continue your Quiz';
    }

    $(document).on('click', 'button:submit',function(){
    	setConfirmUnload(false);
    });

 

</script>
