<?php
//start session
session_start();
require_once 'config/core/configNew.php';
$config= new configNew();
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
 <html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>COCNSORTIUM SCHOLARSHIPS</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="Login and Registration Form with HTML5 and CSS3" />
        <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
        <meta name="author" content="Codrops" />
        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
    </head>
    <body>
        <div class="container">
            <header>
		<!--YOU CAN USE SPAN TO AKE SHIT LIGHT BLUE-->
                <center><h1> <span>WELCOME TO THE PRETEST PORTAL, <?php echo $username = $_SESSION['username']; ?></span><br>BEST OF LUCK!!!</h1></center>
            </header>
            <section>				
                <div id="container_demo" >
                    <!-- hidden anchor to stop jump http://www.css3create.com/Astuce-Empecher-le-scroll-avec-l-utilisation-de-target#wrap4  -->
                    <a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                            <?php


//load and initialize user class
if(isset($_POST['submit'])){
    //check whether user details are empty
    if(!empty($_POST['num_questions']) && !empty($_POST['category']) ){
        //password and confirm password comparison
        $questionsInPage = $_POST['num_questions'];
        $category = $_POST['category'];
        $id = $_SESSION['id'];
        $username = $_SESSION['username'];
           // $username= $config->getUsername($id);
           // $_SESSION['username'] = $username;
         // echo $id;
         //echo $username;
        //exit();
            $questions = $config->getQuestions($id, $questionsInPage, $category);
         /*
                echo "<pre>";
            print_r($questions);
                 echo "</pre>";

    */
}   
        }
   
    ?>

                <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5 start-page">
                    <h1 class="text_underline">Are You Ready??? </h1>
                    <form class="form-signin well" method="post" id="signin" name="signin" action="questions.php" novalidate="novalidate" requireds>
                        
                        <p> 
                            <div class="form-group">
                            <select class="form-control" name="category" id="category">
                                <option value="">Choose your category</option>
                                <?php  
                                     $categories = $config->getCategory();
                                foreach ($categories as $key=>$cate){ 
                                    ?>
                                    <option value="<?php echo $key; ?>"><?php echo $cate; ?></option>
                                <?php } ?>
                            </select> 
                            <span class="help-block"></span>
                        </div>
                        </p>
                            
    
                        <div class="form-group">
                           <p>
                            <select class="form-control" name="num_questions" id="num_questions" required="required">
                                <option value="">Choose number of questions to be showed on each page</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select> 
                    </p>
                            <span class="help-block"></span>
                        </div>
    <br> 
                          <p class="login button"> 
                                    <input type="submit" value="Start!!!" name="submit"/> 
                                </p>
                               

                    </form>
                </div>

                        </div>

                      

                    </div>
                </div>  
            </section>
        
 <form method="POST" action="https://voguepay.com/pay/"><input type="hidden" name="v_merchant_id" value="5565-0048219" /><input type="hidden" name="memo" value="Order from Tijani Abdulazeez" /><input type="hidden" name="cur" value="NGN" /><input type="hidden" name="item_1" value="Application Fee" /><input type="hidden" name="price_1" value="1000" /><input type="hidden" name="description_1" value="Registration fee" /><br /><input type="image" src="https://voguepay.com/images/buttons/make_payment_green.png" alt="PAY" /></form>
                        

        </div>
    </body>
</html>